export interface InvestmentHistory {
    id: number;
    tipo: string;         
    valor: number;        
    rentabilidade: number; 
    data: string;         
  }