 
export interface ProfileResponse {
    clientId: number; 
    nomeCliente: string;
    perfil: string;   // Ex: "Moderado"
    descricao: string;
    pontuacao: number;
  }